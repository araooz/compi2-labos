#ifndef AST_H
#define AST_H

#include <string>
#include <unordered_map>
#include <list>
#include <ostream>

using namespace std;


// Operadores binarios soportados
enum BinaryOp { 
    PLUS_OP, 
    MINUS_OP, 
    MUL_OP, 
    DIV_OP,
    POW_OP
};

// Clase abstracta Exp
class Exp {
public:
    virtual ~Exp() = 0;  // Destructor puro → clase abstracta
    static string binopToChar(BinaryOp op);  // Conversión operador → string
    virtual void toDot(std::ostream& out, int& id) const = 0;  // Visualización en DOT
};

// Expresión binaria
class BinaryExp : public Exp {
public:
    Exp* left;
    Exp* right;
    BinaryOp op;
    BinaryExp(Exp* l, Exp* r, BinaryOp op);
    ~BinaryExp();
    void toDot(std::ostream& out, int& id) const override; 

};

// Expresión numérica
class NumberExp : public Exp {
public:
    int value;
    NumberExp(int v);
    ~NumberExp();
    void toDot(std::ostream& out, int& id) const override; 
};

// Expresión flotante
class FloatExp : public Exp {
public:
    double value;
    FloatExp(double v);
    ~FloatExp();
    void toDot(std::ostream& out, int& id) const override; 
};

// Expresión numérica
class IdExp : public Exp {
public:
    string value;
    IdExp(string v);
    ~IdExp();
    void toDot(std::ostream& out, int& id) const override; 
};

// Raiz cuadrada
class SqrtExp : public Exp {
public:
    Exp* value;
    SqrtExp(Exp* v);
    ~SqrtExp();
    void toDot(std::ostream& out, int& id) const override; 
};

class AbsExp : public Exp {
public:
    Exp* value;
    AbsExp(Exp* v);
    ~AbsExp();
    void toDot(std::ostream& out, int& id) const override; 
};

class MaxExp : public Exp {
public:
    list<Exp*> exp_list;
    MaxExp(list<Exp*> exp_list);
    ~MaxExp();
    void toDot(std::ostream& out, int& id) const override; 
};

class MinExp : public Exp {
public:
    list<Exp*> exp_list;
    MinExp(list<Exp*> exp_list);
    ~MinExp();
    void toDot(std::ostream& out, int& id) const override; 
};

#endif // AST_H
